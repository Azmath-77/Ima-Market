// Authentication scripts for login and signup pages

document.addEventListener("DOMContentLoaded", () => {
    // Login Form Submission
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
      loginForm.addEventListener("submit", (e) => {
        e.preventDefault();
  
        const email = document.getElementById("login-email").value.trim();
        const password = document.getElementById("login-password").value.trim();
  
        if (!email || !password) {
          displayMessage("login-message", "Please fill in all fields.", "error");
          return;
        }
  
        if (!validateEmail(email)) {
          displayMessage("login-message", "Invalid email format.", "error");
          return;
        }
  
        // Simulate authentication request
        if (email === "user@example.com" && password === "password123") {
          displayMessage("login-message", "Login successful! Redirecting...", "success");
          setTimeout(() => {
            window.location.href = "./Welcome.html";
          }, 1500);
        } else {
          displayMessage("login-message", "Invalid email or password.", "error");
        }
      });
    }
  
    // Signup Form Submission
    const signupForm = document.getElementById("signup-form");
    if (signupForm) {
      signupForm.addEventListener("submit", (e) => {
        e.preventDefault();
  
        const email = document.getElementById("signup-email").value.trim();
        const password = document.getElementById("signup-password").value.trim();
        const confirmPassword = document.getElementById("signup-confirm-password").value.trim();
  
        if (!email || !password || !confirmPassword) {
          displayMessage("signup-message", "Please fill in all fields.", "error");
          return;
        }
  
        if (!validateEmail(email)) {
          displayMessage("signup-message", "Invalid email format.", "error");
          return;
        }
  
        if (password.length < 6) {
          displayMessage("signup-message", "Password must be at least 6 characters.", "error");
          return;
        }
  
        if (password !== confirmPassword) {
          displayMessage("signup-message", "Passwords do not match.", "error");
          return;
        }
  
        // Simulate account creation
        displayMessage("signup-message", "Signup successful! Redirecting to login...", "success");
        setTimeout(() => {
          window.location.href = "./Login1.html";
        }, 1500);
      });
    }
  
    // Utility: Validate Email Format
    function validateEmail(email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    }
  
    // Utility: Display Messages
    function displayMessage(elementId, message, type) {
      const messageElement = document.getElementById(elementId);
      if (messageElement) {
        messageElement.textContent = message;
        messageElement.className = type === "success" ? "message success" : "message error";
      }
    }
  });
  