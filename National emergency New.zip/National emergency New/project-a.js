// Expand/Collapse Additional Project Details
document.addEventListener('DOMContentLoaded', () => {
    const toggleButtons = document.querySelectorAll('.toggle-details');

    toggleButtons.forEach(button => {
        button.addEventListener('click', () => {
            const projectDetails = document.getElementById(button.getAttribute('data-project-id'));
            if (projectDetails.style.display === 'none' || projectDetails.style.display === '') {
                projectDetails.style.display = 'block';
                button.textContent = 'Hide Details';
            } else {
                projectDetails.style.display = 'none';
                button.textContent = 'More Details';
            }
        });
    });
});

// Smooth Scrolling for Page Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Back-to-Top Button Functionality
const backToTopButton = document.getElementById('back-to-top');
window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        backToTopButton.style.display = 'block';
    } else {
        backToTopButton.style.display = 'none';
    }
});

backToTopButton.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
