// JavaScript for enhancing the functionality of the index.html page

document.addEventListener("DOMContentLoaded", () => {
    // Smooth scrolling for navigation links
    document.querySelectorAll("a[href^='#']").forEach(anchor => {
      anchor.addEventListener("click", function (e) {
        e.preventDefault();
        const targetId = this.getAttribute("href").substring(1);
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
          targetElement.scrollIntoView({
            behavior: "smooth",
          });
        }
      });
    });
  
    // Toggle project details visibility
    document.querySelectorAll(".toggle-details").forEach(button => {
      button.addEventListener("click", () => {
        const projectId = button.getAttribute("data-project-id");
        const details = document.getElementById(projectId);
        if (details) {
          details.style.display = details.style.display === "block" ? "none" : "block";
        }
      });
    });
  
    // Back to top button functionality
    const backToTopButton = document.getElementById("back-to-top");
    if (backToTopButton) {
      window.addEventListener("scroll", () => {
        if (window.scrollY > 300) {
          backToTopButton.style.display = "block";
        } else {
          backToTopButton.style.display = "none";
        }
      });
  
      backToTopButton.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    }
  
    // Dynamic greeting message
    const greetingElement = document.getElementById("greeting");
    if (greetingElement) {
      const hour = new Date().getHours();
      const greeting =
        hour < 12 ? "Good morning!" : hour < 18 ? "Good afternoon!" : "Good evening!";
      greetingElement.textContent = greeting;
    }
  });
// Dynamic Greeting Based on Time
document.addEventListener('DOMContentLoaded', () => {
    const greetingElement = document.getElementById('greeting');
    const hours = new Date().getHours();
    let greeting;

    if (hours < 12) {
        greeting = "Good Morning!";
    } else if (hours < 18) {
        greeting = "Good Afternoon!";
    } else {
        greeting = "Good Evening!";
    }

    greetingElement.textContent = greeting;
});

// Smooth Scrolling for Navbar Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Back-to-Top Button
const backToTopButton = document.getElementById('back-to-top');
window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        backToTopButton.style.display = 'block';
    } else {
        backToTopButton.style.display = 'none';
    }
});

backToTopButton.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Toggle Project Details
document.querySelectorAll('.toggle-details').forEach(button => {
    button.addEventListener('click', () => {
        const projectDetails = document.getElementById(button.getAttribute('data-project-id'));
        if (projectDetails.style.display === 'none' || projectDetails.style.display === '') {
            projectDetails.style.display = 'block';
        } else {
            projectDetails.style.display = 'none';
        }
    });
});
  